<template>
    <div class="rotulo">

        <div class="elemento">
            <slot></slot>
        </div>
    </div>
</template>
<script>

export default {
    props:{
        nome:{
            type:String,
            required:true
        }
    }
}
</script>

<style>
    .rotulo{
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        color: rgb(59, 69, 77);
       
    }

   
</style>