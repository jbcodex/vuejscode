<template>
  <v-app id="table">
    <v-data-table
      :headers="columns"
      :items="dataForm"
      :items-per-page="8"
      class="elevation-19"
    >
    </v-data-table>
  </v-app>
</template>

<script>
import bus from '../bus'
export default {
  props:{
    items:{
      type:Array,
     
    }
  },
  data() {
    return {
      dataForm:[],
      columns: [
        { text: "Nome", value: "nameF", class: "blue white--text" },
        { text: "E-mail", value: "emailF", class: "blue white--text" },
        { text: "Idade", value: "ageF", class: "blue white--text" },
        { text: "Ações", value: "link", class: "blue white--text" },
      ]
    }
  },
  created(){
    bus.sendDataDone(data =>{
        this.dataForm = data
    })  
  }
}
</script>
<style scoped>
#table {
  height: 300px;
  width: 500px;
  flex-direction: column;
  align-items: center;
  padding: 20px 0;
  
  background-color: #fff0;
}
</style>
