import Vue from 'vue'
export default new Vue({
    methods:{
        BeforeSendData(data){
            this.$emit('sendData', data)
        },
        sendDataDone(data){
            this.$on('sendData', data)
        }
    }
})

