<template>
  <v-app id="app">
    <v-container class="content">
      <v-form class="panel" ref="form">
        <h2>Cadastre-se para acessar</h2>
       
          <v-text-field
            v-model="name"
            placeholder="No mínimo 5 caracteres"
            append-icon="mdi-account-circle-outline"
            label="Nome"
            :rules="nameRules"
            @keyup="allow"
          ></v-text-field>
       
          <v-text-field
            v-model="email"
            placeholder="Insira um e-mail válido"
            append-icon="mdi-email-outline"
            label="E-mail"
            :rules="emailRules"
            @keyup="allow"
          ></v-text-field>
       
          <v-text-field
            v-model.number="age"
            placeholder="1 / 99 - Somente números"
            append-icon="mdi-emoticon-outline"
            label="Idade"
            maxlength="2"
            :rules="ageRules"
            @keyup="allow"
          ></v-text-field>
      
        <v-btn v-if="!allowButton" x-large depressed disabled>
          <v-icon left>mdi-check-circle</v-icon>
          Salvar contato</v-btn>

        <v-btn v-else x-large color="primary" dark @click="setData">
          <v-icon left> mdi-check-circle</v-icon>
          Salvar contato</v-btn>
          
      </v-form>
      <Table>
      </Table>
    </v-container>
  </v-app>
</template>

<script>

import Table from "./components/Table.vue";
import bus from  './bus'
export default {
  components: {
  Table
  },
  name: "App",
  
  data() {
    return {
      name: "",
      email: "",
      age: null,
      allowButton: false,
      nameRules: [
        (v) => !!v || "Nome é obrigatório",
        (v) => v.length > 4 || "Nome com no mínimo 5 caracteres",
        
      ],
      emailRules: [
        (v) => !!v || "Email obrigatório",
        (v) => /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(v) || "E-mail inválido!",
      ],
      ageRules: [(v) => !!v || "Idade obrigatória!"],
     
    }
  },

  methods: {
    allow() {
      if (this.name.length >= 5 && this.validEmail(this.email) && this.age >= 1) {
        this.allowButton = true;
      }

      if (this.age == 0 || this.name == "" || this.name.length < 5 || !this.validEmail(this.email)) {
        this.allowButton = false;
        if (this.age == "") {
          this.age = "";
        }
      }
    },

    setData(){
    const formData = [
      {nameF:this.name, emailF:this.email, ageF:this.age}
    ]
    
     bus.BeforeSendData(formData)
     this.$refs.form.reset()
     this.allowButton=false
     
    },

    validEmail(e){
      var re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      return re.test(e);
    }
  },
 
}
</script>
<style>
#app {
  display: flex;
  font-family: Lato;
  align-items: center;
  justify-content: center;
  background-image: linear-gradient(to top, #0f2027, #203a43, #2c5364);
}

.content {
  display: flex;
  justify-content: center;
  margin: 100px;
}

.panel {
  display: flex;
  width: 300px;
   height: 330px;
  flex-direction: column;
  align-items: center;
  background-color: rgb(255, 255, 255);
  padding: 20px 0;
  box-shadow: #0005 1px 1px 18px;
  margin: 10px;
}

.panel h2 {
  font-family: Lato;
  font-size: 1.2rem;
  color: rgb(25, 26, 36);
  font-weight: 400;
}
.bt {
  font-family: Lato;
  margin: 5px;
}
</style>
